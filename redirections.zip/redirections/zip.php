<?php
/*
Plugin Name: Zip Viewer with Index Display
Description: Menampilkan isi file ZIP dan menampilkan isi file index.php jika ada.
Version: 1.1
Author: Nama Anda
*/

function zip_viewer_shortcode($atts) {
    $atts = shortcode_atts(array(
        'index.zip' => '', // file ZIP yang ingin ditampilkan
    ), $atts, 'zip_viewer');

    $zip_file = $atts['file'];

    if (!file_exists($zip_file)) {
        return "File ZIP tidak ditemukan.";
    }

    $zip = new ZipArchive;
    if ($zip->open($zip_file) === TRUE) {
        $output = '<ul>';
        $index_php_content = '';

        for ($i = 0; $i < $zip->numFiles; $i++) {
            $file_name = $zip->getNameIndex($i);
            $output .= '<li>' . $file_name . '</li>';

            // Cek jika file bernama index.php ditemukan
            if ($file_name == 'index.php') {
                $index_php_content = $zip->getFromIndex($i);
            }
        }
        $output .= '</ul>';

        if (!empty($index_php_content)) {
            // Escape output untuk keamanan
            $output .= '<pre>' . htmlspecialchars($index_php_content) . '</pre>';
        } else {
            $output .= '<p>File index.php tidak ditemukan di dalam ZIP.</p>';
        }

        $zip->close();
    } else {
        return "Tidak bisa membuka file ZIP.";
    }

    return $output;
}

add_shortcode('zip_viewer', 'zip_viewer_shortcode');
?>
